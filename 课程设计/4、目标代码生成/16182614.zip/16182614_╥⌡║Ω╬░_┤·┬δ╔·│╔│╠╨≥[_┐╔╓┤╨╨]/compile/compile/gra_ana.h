#include<stdio.h>
#include<stdlib.h>
extern void program();
extern int array_flag;
extern int var_flag;
extern int const_flag;
extern int para_flag;
extern int global_flag;
extern int addr;
extern int max_var_num;
extern char mid_array[100];
extern char mid_empty[100];
extern char src1[100], src2[100],result[100];
extern char f_token[100];
extern char tep_result[100];
extern char mid_zero[100];
extern char switch_label[100];
extern char mid_int[100];
extern char mid_char[100];
extern char mid_str[100];